#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Aug 30 17:05:31 2023

@author: nfamartins
"""

from .get_data import get_data